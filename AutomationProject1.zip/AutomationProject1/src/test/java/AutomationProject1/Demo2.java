package AutomationProject1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Demo2 {
	public class demo1 {
		WebDriver cdriver;
		 @Test (priority=1)
		 //Register page//
		  public void Testcase1() {
			 WebDriverManager.chromedriver().setup();
			 ChromeOptions options = new ChromeOptions();
			 options.addArguments("--remote-allow-origins=*");
			 cdriver=new ChromeDriver(options);
			// cdriver = new ChromeDriver();
			 cdriver.get("https://demo.nopcommerce.com");//testcase1 Register page//
			 cdriver.manage().window().maximize();
			 System.out.println("title:"+cdriver.getTitle());
			 cdriver.get("https://demo.nopcommerce.com/register");
			 System.out.println("title:"+cdriver.getTitle());
			//WebDriverWait mywait = new WebDriverWait(driver,duraction.ofSeconds(10));
		  cdriver.findElement(By.id("gender-female")).click();	  // Test case2 gender// 
		  cdriver.findElement(By.id("FirstName")).sendKeys("Babitha");//Test case3 Names//
		  cdriver.findElement(By.id("LastName")).sendKeys("J");
		 } 
	   @Test (priority=2) 
	   public void Testcase2() {
	   	Select date =new Select(cdriver.findElement(By.name("DateOfBirthDay"))); //Test case4 date of birth//
		 date.selectByIndex(13);
		 Select month =new Select(cdriver.findElement(By.name("DateOfBirthMonth")));	 //date of birth//
		 month.selectByIndex(2);
		 Select year= new Select(cdriver.findElement(By.name("DateOfBirthYear")));
		 year.selectByValue("2001");
		 cdriver.findElement(By.id("Email")).sendKeys("janardhanbabitha@gmail.com");	//Test case 5 Email id//
	   }
		 @Test (priority=3)
		 public void Testcase3() throws InterruptedException {
		cdriver.findElement(By.id("Company")).sendKeys("Nykaa");	//Test case 6 company details//
		 //News letter box
		cdriver.findElement(By.xpath("html/body/div[6]/div[3]/div/div/div/div[2]/form/div[3]/div[2]/div")).click(); // Test case 7 News letter//
		//password//
		cdriver.findElement(By.id("Password")).sendKeys("12345678"); //Test case 8 password//
		cdriver.findElement(By.id("ConfirmPassword")).sendKeys("12345678");
		Thread.sleep(2000);

		WebElement button = cdriver.findElement(By.id("register-button"));//Test case 9 Register button click//
		button.click();
		}
	  @Test (priority=4)//adding customer login page
	  public void Testcase5() throws InterruptedException { 
		  Thread.sleep(2000);
		  cdriver.findElement(By.xpath("html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click(); // Test case 10 Email and password//
		  cdriver.findElement(By.id("Email")).sendKeys("janardhanbabitha@gmail.com");
		  cdriver.findElement(By.id("Password")).sendKeys("12345678");
		  cdriver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();//Test case 11login button//
		  Thread.sleep(2000);
	  }
	  @Test (priority=5) // product page //
	  public void Testcase6() throws InterruptedException {
		 cdriver.findElement(By.id("small-searchterms")).sendKeys("Asus N551JK-XO076H Laptop");//Test case 11search product//
		 cdriver.findElement(By.xpath("//*[@id=\"small-search-box-form\"]/button")).click();
		 Thread.sleep(2000);
		  cdriver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[2]/div/div[2]/div[3]/div/div[2]/div/div/div[1]/div/div[2]/div[3]/div[2]/button[1]")).click();
		  cdriver.findElement(By.linkText("Asus N551JK-XO076H Laptop")).click();// Test case 12 add to cart //
		  Thread.sleep(2000);
			 cdriver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();
		  //cdriver.findElement(By.xpath("//*[@id=\"add-to-cart-button-5\"]")).click();//Testcase13 add to cart button//
	 }
	 @Test (priority=6) //shopping cart //
	 public void Testcase7() throws InterruptedException {
		 //cdriver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();  //Test case 14 shopping cart//
		 //cdriver.findElement(By.xpath("//*[@id=\"open-estimate-shipping-popup\"]")).click();// Test case 15 Goto cart//
		 cdriver.findElement(By.xpath("//*[@id=\"open-estimate-shipping-popup\"]")).click();
		 Thread.sleep(2000);
		 Select s=new Select(cdriver.findElement( By.xpath("//*[@id=\"CountryId\"]")));
		 s.selectByVisibleText("India");
		 cdriver.findElement(By.id("ZipPostalCode")).sendKeys("625010");
		 Thread.sleep(2000);
		 List <WebElement> shopping=cdriver.findElements(By.xpath("//*[@type='radio']"));
                 		 int cnt=shopping.size();
		 System.out.println("Size of the radio "+cnt);
		 cdriver.findElement(By.xpath("//*[@id=\"estimate-shipping-popup\"]/div[4]/div[2]/div[3]/div[1]")).click();
		 cdriver.findElement(By.xpath("//*[@id=\"estimate-shipping-popup\"]/div[5]/button")).click();
		 Thread.sleep(2000);
	 }
	 @Test (priority=7)//logout
	 public void Testcase8() {
	 cdriver.findElement(By.cssSelector(".ico-logout")).click();
	 }
	}}

  
 

