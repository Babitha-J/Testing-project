package nopcommerce;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;

public class demo1 {
	WebDriver cdriver;
	 @BeforeClass
	 //Register page//
	  public void Testcase1() {
		 WebDriverManager.chromedriver().setup();
		 cdriver = new ChromeDriver();
		 cdriver.get("https://demo.nopcommerce.com");//testcae1 Register page//
		 cdriver.manage().window().maximize();
		 System.out.println("title:"+cdriver.getTitle());
		 cdriver.get("https://demo.nopcommerce.com/register");
		 System.out.println("title:"+cdriver.getTitle());
		//WebDriverWait mywait = new WebDriverWait(driver,duraction.ofSeconds(10));
	  cdriver.findElement(By.id("gender-female")).click();	  // Test case2 gender// 
	  cdriver.findElement(By.id("FirstName")).sendKeys("Babitha");//Test case3 Names//
	  cdriver.findElement(By.id("LastName")).sendKeys("J");
	 } 
   @Test (priority=2) 
   public void Testcase2() {
   	Select d =new Select(cdriver.findElement(By.name("DateOfBirthDay"))); //Test case4 date of birth//
	 d.selectByIndex(13);
	 Select m =new Select(cdriver.findElement(By.name("DateOfBirthMonth")));	 //date of birth//
	 m.selectByIndex(2);
	 Select y= new Select(cdriver.findElement(By.name("DateOfBirthYear")));
	 y.selectByValue("2001");
	 cdriver.findElement(By.id("Email")).sendKeys("janardhanbabitha@gmail.com");	//Test case 5 Email id//
   }
	 @Test (priority=3)
	 public void Testcase3() throws InterruptedException {
	cdriver.findElement(By.id("Company")).sendKeys("Nykaa");	//Test case 6 company details//
	 //News lettar
	cdriver.findElement(By.xpath("html/body/div[6]/div[3]/div/div/div/div[2]/form/div[3]/div[2]/div")).click(); // Test case 7 News letter//
	//password//
	cdriver.findElement(By.id("Password")).sendKeys("12345678"); //Test case 8 password//
	cdriver.findElement(By.id("ConfirmPassword")).sendKeys("12345678");
	Thread.sleep(2000);
	WebElement button = cdriver.findElement(By.id("register-button"));//Test case 9 Register button click//
	button.click();
	}
  @Test (priority=4)//adding customer login page
  public void Testcase5() throws InterruptedException { 
	  Thread.sleep(2000);
	  cdriver.findElement(By.xpath("html/body/div[6]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click(); // Test case 10 Email and password//
	  cdriver.findElement(By.id("Email")).sendKeys("janardhanbabitha@gmail.com");
	  cdriver.findElement(By.id("Password")).sendKeys("12345678");
	  cdriver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div/div/div[2]/div[1]/div[2]/form/div[3]/button")).click();//Test case 11login button//
	  Thread.sleep(2000);
  }
  @Test (priority=5) // product page //
  public void Testcase6() throws InterruptedException {
	 cdriver.findElement(By.id("small-searchterms")).sendKeys("Asus N551JK-XO076H Laptop");//Test case 11search product//
	 cdriver.findElement(By.xpath("//*[@id=\"small-search-box-form\"]/button")).click();
	 Thread.sleep(2000);
	  cdriver.findElement(By.xpath("/html/body/div[6]/div[3]/div/div[2]/div/div[2]/div[3]/div/div[2]/div/div/div[1]/div/div[2]/div[3]/div[2]/button[1]")).click();
	  cdriver.findElement(By.linkText("Asus N551JK-XO076H Laptop")).click();// Test case 12 add to cart //
	  Thread.sleep(2000);
	  cdriver.findElement(By.xpath("//*[@id=\"add-to-cart-button-5\"]")).click();//Testcase13 add to cart button//
 }
 @Test (priority=6) //shopping cart //
 public void Testcase7() throws InterruptedException {
	 cdriver.findElement(By.xpath("//*[@id=\"topcartlink\"]/a/span[1]")).click();  //Test case 14 shopping cart//
	 cdriver.findElement(By.xpath("//*[@id=\"open-estimate-shipping-popup\"]")).click();// Test case 15 Goto cart//
	 Thread.sleep(2000);
	 cdriver.findElement(By.xpath("\"//*[@id=\\\"open-estimate-shipping-popup\\\"]\")).click();
			 Thread.sleep(2000);"))
	 //cdriver.findElement(By.xpath("div[@class='estimate-shipping-row shipping-option active']//label\n")).click(); //Test case 16 shipping cart//
	 //cdriver.findElement(By.xpath("//a[@id='open-estimate-shipping-popup']")).click(); 
	 }
 @Test(priority=7) //shipping to page//
 public void Testcase8() throws InterruptedException {
	 Select c = new Select(cdriver.findElement(By.id("CountryId"))); 		//Test case17 country//
	 c.selectByVisibleText("India");
	 Select o = new Select(cdriver.findElement(By.id("StateProvinceId"))); //Test case18  other//
	 o.selectByIndex(0);
	 cdriver.findElement(By.id("ZipPostalCode")).sendKeys("585214");// Test case 19 portal code//
 }
 @Test (priority=8) //shipping method//
 public void Testcase9() {
 cdriver.findElement(By.xpath("//body/div[@class='mfp-wrap mfp-close-btn-in mfp-auto-cursor estimate-shipping-popup-zoom-in mfp-ready']/div[@class='mfp-container mfp-s-ready mfp-inline-holder']/div[@class='mfp-content']")).click();
//cdriver.findElement(By.xpath("html/body/div[2]/div/div[1]/div/div[5]/button")).click(); // Test case 20 Apply button//
 }	
}
